package com.kuafu.common.delay_task.domain;

/**
 * 只是一个标识
 */
public class DelayTask {
}
