package com.kuafu.web.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


@Data
public class MemberLevelEnumMemberLevelEnumIdStatusStatistic22ba9e80Count {

        @Data
        @NoArgsConstructor
        public static class Statistic0{


                        @JsonProperty("name")





                private   String memberLevelEnumId;



                @JsonProperty("value")



                private   String result_kf;

        }
}
