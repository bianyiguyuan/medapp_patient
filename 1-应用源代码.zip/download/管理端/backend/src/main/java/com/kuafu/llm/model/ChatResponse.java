package com.kuafu.llm.model;

import lombok.Data;

@Data
public class ChatResponse {
    private String conversionId;
    private String answer;
}
