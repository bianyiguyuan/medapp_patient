package com.kuafu.web.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


@Data
public class OrderInfoStatistic13a72ffbCount {

        @Data
        @NoArgsConstructor
        public static class Statistic0{


                        @JsonProperty("name")





                private   String productInfoProductInfoId;



                @JsonProperty("value")



                private   String result_kf;

        }
}
