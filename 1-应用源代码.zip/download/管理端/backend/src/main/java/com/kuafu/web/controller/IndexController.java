package com.kuafu.web.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class IndexController {
}
