package com.kuafu.web.vo;

public class IndexVo {
}
