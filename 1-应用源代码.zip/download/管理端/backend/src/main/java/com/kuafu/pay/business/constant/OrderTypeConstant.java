package com.kuafu.pay.business.constant;

public class OrderTypeConstant {
    public static final String NORMAL = "normal";
}
