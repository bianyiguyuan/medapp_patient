package com.kuafu.common.delay_task.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class DelayTaskConfig {


}
