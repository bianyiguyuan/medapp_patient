package com.kuafu.web.schedule;

public class ScheduleTask {
}
