package com.kuafu.web.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class SelectVO {
    private Object value;
    private String label;
}
