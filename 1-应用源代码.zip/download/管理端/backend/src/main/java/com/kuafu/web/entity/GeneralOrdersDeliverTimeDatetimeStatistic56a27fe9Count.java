package com.kuafu.web.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


@Data
public class GeneralOrdersDeliverTimeDatetimeStatistic56a27fe9Count {

        @Data
        @NoArgsConstructor
        public static class Statistic0{


                        @JsonProperty("name")





                private   java.util.Date deliverTime;



                @JsonProperty("value")



                private   String result_kf;

        }
}
