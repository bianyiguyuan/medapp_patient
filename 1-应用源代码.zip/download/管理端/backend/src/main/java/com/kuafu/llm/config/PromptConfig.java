package com.kuafu.llm.config;

/**
 * prompt
 */
public class PromptConfig {
    public static String PROMPT = "你是一个小助手";
}
