package com.kuafu.web.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


@Data
public class GeneralOrdersDeliveryStatusStatusStatistic4f231347Count {

        @Data
        @NoArgsConstructor
        public static class Statistic0{


                        @JsonProperty("name")





                private   String deliveryStatus;



                @JsonProperty("value")



                private   String result_kf;

        }
}
