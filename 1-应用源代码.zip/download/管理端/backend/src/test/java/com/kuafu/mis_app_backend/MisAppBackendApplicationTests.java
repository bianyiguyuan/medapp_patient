package com.kuafu.mis_app_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MisAppBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
